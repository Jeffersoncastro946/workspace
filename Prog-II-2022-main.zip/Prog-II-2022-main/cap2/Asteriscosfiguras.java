//Ejercicio 18, visualizacion de figuras con asteriscos (cap2)

import javax.swing.JOptionPane;

public class Asteriscosfiguras {
    public static void main(String[] args) throws Exception {
    
        JOptionPane.showMessageDialog(null, "***********\n*                *\n*                *\n***********");
        JOptionPane.showMessageDialog(null, "      *\n    ***\n  *****\n *******\n  *****\n    ***\n      *\n");
        JOptionPane.showMessageDialog(null, "    *\n  *** \n*****\n   *\n   *\n   *\n   *\n   *\n");
        JOptionPane.showMessageDialog(null, "    ***\n *       *\n*         *\n*         *\n *       *\n    ***");

    }
}
