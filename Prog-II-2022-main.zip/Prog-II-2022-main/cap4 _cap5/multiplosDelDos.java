// Ejercicio 4.33 Múltiplos de 2 con un ciclo infinito (cap4)


public class multiplosDelDos{
    public static void main(String[] args)
    {
        int dos = 2;
        
        System.out.println(dos);
        
        while (dos > 0)
        {
            dos+=2;
            
            System.out.println(dos);
        }
    }
}
